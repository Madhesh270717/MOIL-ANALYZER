"""
MOIL Manganese Reserve Prediction Model
Trains a Random Forest classifier on geological + structural features
to predict manganese occurrence probability.
"""
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, roc_auc_score, classification_report, confusion_matrix
from sklearn.preprocessing import LabelEncoder
import joblib

# 1. Load data
df = pd.read_csv("01_Geological_Data.csv")

# 2. Encode categorical columns
le_unit = LabelEncoder()
le_rock = LabelEncoder()
df["Geological_Unit_enc"] = le_unit.fit_transform(df["Geological_Unit"])
df["Rock_Type_enc"] = le_rock.fit_transform(df["Rock_Type"])

# 3. Feature columns (surface + structural "sub-surface proxy" indicators)
feature_cols = [
    "Geological_Unit_enc", "Rock_Type_enc", "Geological_Age_Ma",
    "Elevation_m", "Fault_Distance_km", "Lineament_Density_km_per_km2",
    "Geochemical_Mn_ppm"
]
X = df[feature_cols]
y = df["Known_Manganese_Occurrence"]

# 4. Train/test split (stratified to preserve class balance)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# 5. Train Random Forest
model = RandomForestClassifier(
    n_estimators=300, max_depth=8, min_samples_leaf=3,
    class_weight="balanced", random_state=42
)
model.fit(X_train, y_train)

# 6. Evaluate
y_pred = model.predict(X_test)
y_proba = model.predict_proba(X_test)[:, 1]

acc = accuracy_score(y_test, y_pred)
auc = roc_auc_score(y_test, y_proba)

print("=" * 50)
print("MOIL RESERVE PREDICTION MODEL — RESULTS")
print("=" * 50)
print(f"Training samples: {len(X_train)}  |  Test samples: {len(X_test)}")
print(f"Accuracy: {acc:.3f}")
print(f"AUC Score: {auc:.3f}")
print("\nClassification Report:")
print(classification_report(y_test, y_pred, target_names=["No Manganese", "Manganese"]))
print("Confusion Matrix:")
print(confusion_matrix(y_test, y_pred))

# 7. Feature importance
importances = pd.Series(model.feature_importances_, index=feature_cols).sort_values(ascending=False)
print("\nFeature Importance (what the model relies on most):")
print(importances)

# 8. Predict probability for ALL 300 sites (for map visualization)
df["Predicted_Probability"] = model.predict_proba(X[feature_cols])[:, 1]
df["Predicted_Zone"] = pd.cut(
    df["Predicted_Probability"], bins=[-0.01, 0.33, 0.66, 1.0],
    labels=["Low", "Medium", "High"]
)
df.to_csv("reserve_predictions_all_sites.csv", index=False)

# 9. Save model for reuse in the dashboard backend
joblib.dump(model, "reserve_model.pkl")
joblib.dump({"unit": le_unit, "rock": le_rock}, "label_encoders.pkl")

print("\nSaved: reserve_predictions_all_sites.csv, reserve_model.pkl")
